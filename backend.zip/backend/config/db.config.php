<?php
// Database Configuration
return [
    'host' => '162.214.204.205',
    'dbname' => 'dskalmun_appDSK',
    'username' => 'dskalmun_Admin',
    'password' => 'Itadmin@1993',
    'charset' => 'utf8mb4'
];
?>
